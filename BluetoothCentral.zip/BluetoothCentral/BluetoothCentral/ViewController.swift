//
//  ViewController.swift
//  BluetoothCentral
//
//  Created by SD.Man on 2021/2/2.
//

import UIKit
import CoreBluetooth

let heartRateServiceUUID = CBUUID(string: "180D")
let heartRateControllerPointCharacteristicUUID = CBUUID(string: "2A39")
let bodySensorLocationCharacteristicUUID = CBUUID(string: "2A38")
let heartRateMeasurementCharacteristicUUID = CBUUID(string: "2A37")

class ViewController: UIViewController {

    
    @IBOutlet weak var writeCharacteristicTextField: UITextField!
    
    @IBOutlet weak var sensorLocationLabel: UILabel!
    
    @IBOutlet weak var heartRateLabel: UILabel!
    
    var centralManager: CBCentralManager!
    
    var peripheral: CBPeripheral!
    
    var heartRateControllerPointCharacteristic: CBCharacteristic?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        centralManager = CBCentralManager(delegate: self, queue: nil)
    }

    @IBAction func write(_ sender: Any) {
        // 判断是否有该特征
        guard let controllerPointCharacteristic = heartRateControllerPointCharacteristic else { return }
        peripheral.writeValue(writeCharacteristicTextField.text!.data(using: .utf8)!, for: controllerPointCharacteristic, type: .withResponse)
    }
    
}

extension ViewController: CBCentralManagerDelegate {
    // 实例化CBCentralManager之后调用该函数
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        
        case .unknown:
            print("未知状态")
        case .resetting:
            print("蓝牙重置中")
        case .unsupported:
            print("本机不支持BLE")
        case .unauthorized:
            print("未授权")
        case .poweredOff:
            print("蓝牙未开启")
        case .poweredOn:
            print("蓝牙已开启")
            // 开始扫描
            central.scanForPeripherals(withServices: [heartRateServiceUUID])
        @unknown default:
            print("unknown error")
        }
    }
    
    // 发现设备
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        // 强引用
        self.peripheral = peripheral
        // 停止扫描
        central.stopScan()
        // 触发其他钩子函数
        central.connect(peripheral)
        
    }
    
    // 连接成功
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        // 触发回调函数
        peripheral.delegate = self
        // 由外设发现service和characteristic
        peripheral.discoverServices([heartRateServiceUUID])
    }
    
    // 连接失败
    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        print("连接失败")
    }
    
    // 连接断开
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        print("尝试重连")
        central.connect(peripheral)
    }
    
}

extension ViewController: CBPeripheralDelegate {
    // peripheral.discoverServices([heartRateServiceUUID])触发该函数
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if let error = error {
            print("没找到服务，原因是：\(error.localizedDescription)")
        }
        guard let service = peripheral.services?.first else { return }
        // 寻找该服务的特征
        peripheral.discoverCharacteristics([
            heartRateControllerPointCharacteristicUUID,
            bodySensorLocationCharacteristicUUID,
            heartRateMeasurementCharacteristicUUID
        ], for: service)
    }
    
    // peripheral.discoverCharacteristics()触发该函数
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        if let error = error {
            print("没找到特征，原因是：\(error.localizedDescription)")
        }
        // 获取所有特征
        guard let characteristics = service.characteristics else { return }
        
        // 对每个特征属性值进行判断
        for characteristic in characteristics {
            // 当包含可写权限时
            if characteristic.properties.contains(.write) {
                // 触发某个钩子函数
                peripheral.writeValue("100".data(using: .utf8)!, for: characteristic, type: .withResponse)
                self.heartRateControllerPointCharacteristic = characteristic
            }
            // 当包含可读权限时
            if characteristic.properties.contains(.read) {
                // 触发某个钩子函数
                peripheral.readValue(for: characteristic)
            }
            // 当包含订阅权限时
            if characteristic.properties.contains(.notify) {
                // 触发某个钩子函数
                peripheral.setNotifyValue(true, for: characteristic)
            }
        }
    }
    
    // writeValue的钩子函数
    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        if let error = error {
            print("写入失败，原因是：\(error.localizedDescription)")
            return
        }
        print("写入成功")
    }
    
    // peripheral.setNotifyValue第一次会查询是否订阅成功
    func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        if let error = error {
            print("订阅失败，原因是：\(error.localizedDescription)")
        }
    }
    
    // readValue和setNotifyValue的钩子函数
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        if let error = error {
            print("读取失败，原因是：\(error.localizedDescription)")
            return
        }
        
        switch characteristic.uuid {
        case bodySensorLocationCharacteristicUUID:
            sensorLocationLabel.text = String(data: characteristic.value!, encoding: .utf8)
        case heartRateMeasurementCharacteristicUUID:
            guard let heartRate = Int(String(data: characteristic.value!, encoding: .utf8)!) else { return }
            heartRateLabel.text = "\(heartRate)"
        default:
            break
        }
    }
    
}

