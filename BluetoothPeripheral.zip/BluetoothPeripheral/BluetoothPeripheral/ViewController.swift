//
//  ViewController.swift
//  BluetoothPeripheral
//
//  Created by SD.Man on 2021/2/3.
//

import UIKit
import CoreBluetooth

let serviceUUID = CBUUID(string: "B2B6A228-C29E-43DD-8A31-9FA588D386A7")
let writeUUID = CBUUID(string: "C62AE801-D196-4205-9088-7A26B20D21EE")
let readUUID = CBUUID(string: "A7F997FA-230B-4038-A2DB-D85F8D3A924F")
let notifyUUID = CBUUID(string: "32AF79E7-8640-4E93-BBE9-CB110C10A5C4")

class ViewController: UIViewController {
    
    @IBOutlet weak var writeLabel: UILabel!
    @IBOutlet weak var readLabel: UILabel!
    @IBOutlet weak var notifyLabel: UILabel!
    
    var peripheralManager: CBPeripheralManager!
    var writeCharacteristic: CBMutableCharacteristic!
    var notifyCharacteristic: CBMutableCharacteristic!
    
    var timer: Timer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        peripheralManager = CBPeripheralManager(delegate: self, queue: nil)
    }


}

extension ViewController: CBPeripheralManagerDelegate {
    
    func peripheralManagerDidUpdateState(_ peripheral: CBPeripheralManager) {
        switch peripheral.state {
        case .unknown:
            print("未知状态")
        case .resetting:
            print("蓝牙重置中")
        case .unsupported:
            print("蓝牙不支持BLE")
        case .unauthorized:
            print("蓝牙未授权")
        case .poweredOff:
            print("蓝牙已关闭")
        case .poweredOn:
            print("蓝牙已打开")
            // 创建可变服务并设置为主服务
            let services = CBMutableService(type: serviceUUID, primary: true)
            
            // 创建可变特征并添加到服务中,如果data事先设定会给permissions添加readable权限
            writeCharacteristic = CBMutableCharacteristic(type: writeUUID, properties: .write, value: nil, permissions: .writeable)
            let readCharacteristic = CBMutableCharacteristic(type: readUUID, properties: .read, value: nil, permissions: .readable)
            notifyCharacteristic = CBMutableCharacteristic(type: notifyUUID, properties: .notify, value: nil, permissions: .readable)
            
            services.characteristics = [writeCharacteristic, readCharacteristic, notifyCharacteristic]
            
            // 添加服务到外设，由外设管理器负责,同样会触发didAdd回调函数
            peripheralManager.add(services)
            
            // 开始广播，触发didStartAdvertising回调函数
            peripheralManager.startAdvertising([CBAdvertisementDataServiceUUIDsKey: [serviceUUID]])
            
        @unknown default:
            print("未知错误")
        }
    }
    
    // 添加服务触发该回调函数
    func peripheralManager(_ peripheral: CBPeripheralManager, didAdd service: CBService, error: Error?) {
        if let error = error {
            print("添加服务失败，原因是：\(error.localizedDescription)")
        }
    }
    // 开始广播触发该回调函数
    func peripheralManagerDidStartAdvertising(_ peripheral: CBPeripheralManager, error: Error?) {
        if let error = error {
            print("广播失败，原因是：\(error.localizedDescription)")
        }
    }
    
    // 等待中心设备连接之后开始处理请求
    // 写入请求——当中心设备发送(对一个或多个特征值的)写入请求时
    func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveWrite requests: [CBATTRequest]) {
        // 获取请求，根据业务逻辑进行修改
        let request = requests[0]
        // 判断请求写入的特征是否具有写入权限
        if request.characteristic.properties.contains(.write) {
            // 给当前请求的特征改值
            // 不能直接给request.characteristic.value赋值，因为是一个不可变特征
            writeCharacteristic.value = request.value
            // 显示到视图
            writeLabel.text = String(data: request.value!, encoding: .utf8)
            // 给中心设备反馈，以便中心设备可以触发一些delegate方法
            peripheral.respond(to: request, withResult: .success)
        } else {
            peripheral.respond(to: request, withResult: .writeNotPermitted)
        }
    }
    
    // 读取请求,为request.value进行赋值
    func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveRead request: CBATTRequest) {
        if request.characteristic.properties.contains(.read) {
            // The data that the central reads from or writes to the peripheral.
            request.value = readLabel.text?.data(using: .utf8)
            // Responds to a read or write request from a connected central.
            peripheral.respond(to: request, withResult: .success)
        } else {
            peripheral.respond(to: request, withResult: .readNotPermitted)
        }
    }
    
    // 订阅请求,订阅某个特征
    func peripheralManager(_ peripheral: CBPeripheralManager, central: CBCentral, didSubscribeTo characteristic: CBCharacteristic) {
        //用计时器模拟外设数据的实时变动
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { (timer) in
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy年MM月dd日 HH时mm分ss秒"
            let dateStr = dateFormatter.string(from: Date())
            
            self.notifyLabel.text = dateStr//也同时实时显示到本外设上来，方便演示
            // Send an updated characteristic value to one or more subscribed centrals, using a notification or indication.
            // onSubscribedCentrals设为nil表示向所有订阅中心设备发送更新
            // 如果传输队列满了会返回false，调用peripheralManagerIsReady(toUpdateSubscribers peripheral: CBPeripheralManager)
            self.peripheralManager.updateValue(dateStr.data(using: .utf8)!, for: self.notifyCharacteristic, onSubscribedCentrals: nil)
        }
    }
    
    // 传输队列已满，更新不成功，调用该回调函数
    func peripheralManagerIsReady(toUpdateSubscribers peripheral: CBPeripheralManager) {
        //用计时器模拟外设数据的实时变动
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { (timer) in
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy年MM月dd日 HH时mm分ss秒"
            let dateStr = dateFormatter.string(from: Date())
            
            self.notifyLabel.text = dateStr//也同时实时显示到本外设上来，方便演示
            // Send an updated characteristic value to one or more subscribed centrals, using a notification or indication.
            // onSubscribedCentrals设为nil表示向所有订阅中心设备发送更新
            // 如果传输队列满了会返回false，调用peripheralManagerIsReady(toUpdateSubscribers peripheral: CBPeripheralManager)
            self.peripheralManager.updateValue(dateStr.data(using: .utf8)!, for: self.notifyCharacteristic, onSubscribedCentrals: nil)
        }
    }
    
    // 取消订阅
    func peripheralManager(_ peripheral: CBPeripheralManager, central: CBCentral, didUnsubscribeFrom characteristic: CBCharacteristic) {
        timer?.invalidate()
    }
}

